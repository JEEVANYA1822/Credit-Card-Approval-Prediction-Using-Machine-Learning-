import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load the dataset (replace 'dataset.csv' with the actual path)
data = pd.read_csv('dataset.csv')

# Display the first few rows
print("Dataset Preview:")
print(data.head())

# Display column names for debugging purposes
print("\nDataset Columns:")
print(data.columns)

# Define the target column
# Replace 'NAME_INCOME_TYPE' or another column if you have a better candidate for a target column.
# Example: Converting 'NAME_INCOME_TYPE' into a binary target (e.g., 'Working' as 1 and others as 0)
target_column = 'Approval_Status'  # Replace or create the target column dynamically if needed

if target_column not in data.columns:
    # Example: Converting 'NAME_INCOME_TYPE' into a binary target
    data[target_column] = data['NAME_INCOME_TYPE'].apply(lambda x: 1 if x == 'Working' else 0)
    print(f"\nCreated Target Column '{target_column}' from 'NAME_INCOME_TYPE'.")

# Handle missing values
# Fill numeric columns with the median
numeric_columns = data.select_dtypes(include='number')
data[numeric_columns.columns] = numeric_columns.fillna(numeric_columns.median())

# Encode categorical variables
label_encoders = {}
for column in data.select_dtypes(include='object').columns:
    label_encoders[column] = LabelEncoder()
    data[column] = label_encoders[column].fit_transform(data[column])

# Split data into features and target
X = data.drop(target_column, axis=1)
y = data[target_column]

# Scale numerical features
scaler = StandardScaler()
X = pd.DataFrame(scaler.fit_transform(X), columns=X.columns)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train a Random Forest model to assess feature importance
rf = RandomForestClassifier(random_state=42)
rf.fit(X_train, y_train)

# Display feature importance
importances = pd.DataFrame({'Feature': X.columns, 'Importance': rf.feature_importances_}).sort_values(by='Importance', ascending=False)
print("\nFeature Importances:")
print(importances)

# Train and evaluate models
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(),
    "Gradient Boosting": GradientBoostingClassifier()
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    results[name] = accuracy_score(y_test, y_pred)

# Display model performance
print("\nModel Performance:")
for model_name, accuracy in results.items():
    print(f"{model_name}: {accuracy:.2f}")

# Detailed report for Random Forest
print("\nRandom Forest Classification Report:")
print(classification_report(y_test, rf.predict(X_test)))

# Define prediction function
def predict_credit_approval(user_input):
    """
    Predict credit approval for a single user input.

    Args:
        user_input (dict): A dictionary where keys are feature names and values are feature values.

    Returns:
        str: 'Approved' or 'Denied' based on the prediction.
    """
    user_input = pd.DataFrame([user_input])
    user_input = pd.DataFrame(scaler.transform(user_input), columns=X.columns)
    prediction = rf.predict(user_input)
    return "Approved" if prediction[0] == 1 else "Denied"

# Example usage
# Replace keys with actual feature names from your dataset
user_input = {
    'CNT_CHILDREN': 0,
    'AMT_INCOME_TOTAL': 200000,
    'NAME_EDUCATION_TYPE': 1,
    'NAME_FAMILY_STATUS': 0,
    'DAYS_BIRTH': -10000,
    'DAYS_EMPLOYED': -2000,
    'CNT_FAM_MEMBERS': 2,
    # Add additional features as necessary
}
print("\nExample Prediction:")
try:
    print(predict_credit_approval(user_input))
except Exception as e:
    print(f"Error in prediction: {e}")